# Système de recommandation IA pour le renforcement de la cyberrésilience des PME

Application web (Streamlit) permettant à une PME de s'auto-évaluer sur 5 axes de cybersécurité et d'obtenir, en fin de parcours, un rapport de recommandations priorisées, exportable en PDF. Les recommandations et leurs justifications s'appuient sur le guide **CMRPI/AUSIM**.

## Sommaire

- [Fonctionnalités](#fonctionnalités)
- [Architecture du projet](#architecture-du-projet)
- [Prérequis](#prérequis)
- [Installation](#installation)
- [Lancer l'application](#lancer-lapplication)
- [Utilisation](#utilisation)
- [Les 5 axes du questionnaire](#les-5-axes-du-questionnaire)
- [Génération du rapport PDF](#génération-du-rapport-pdf)
- [Stack technique](#stack-technique)

## Fonctionnalités

- **Identification de l'entreprise** : nom, secteur d'activité et email de contact, avec validation du format et du domaine de messagerie.
- **Questionnaire en 5 axes** couvrant les principaux volets de la cybersécurité en entreprise (postes de travail, réseau, sensibilisation, échanges électroniques, protection des données).
- **Moteur de recommandations** : pour chaque réponse donnée, génère une liste de recommandations classées par priorité (Critique / Élevée / Moyenne), chacune associée à une référence précise du guide CMRPI/AUSIM et à sa justification.
- **Rapport interactif** : synthèse visuelle du nombre de recommandations par niveau de priorité, détail par question.
- **Export PDF** du rapport complet, prêt à être partagé ou archivé.

## Architecture du projet

```
.
├── app.py                        # Point d'entrée Streamlit, gestion des étapes (routing)
├── requirements.txt               # Dépendances Python
├──README.md
├── core/
│   ├── etat_session.py            # Initialisation / réinitialisation de l'état de session
│   ├── validation.py               # Validation du format email et du domaine autorisé
│   └── moteur_recommandation.py   # Génère et trie les recommandations selon le profil de réponses
├── data/
│   └── questionnaire.py           # Questions, réponses possibles et recommandations associées
├── pdf/
│   ├── generer_rapport.py         # Construction du rapport PDF (reportlab)
│   └── style_pdf.py                # Constantes de style (couleurs par priorité, etc.)
└── ui/
    ├── identification.py          # Écran 1 : formulaire d'identification de l'entreprise
    ├── questionnaire_ui.py        # Écran 2 : formulaire du questionnaire
    └── resultats.py                # Écran 3 : affichage du rapport + bouton de téléchargement PDF
```

Le flux applicatif est piloté par `st.session_state.etape`, qui prend successivement les valeurs `"identification"` → `"questionnaire"` → `"resultats"` (voir `app.py` et `core/etat_session.py`).

## Prérequis

- Python 3.9 ou supérieur
- pip

## Installation

```bash
# Cloner ou récupérer le projet, puis se placer dans le dossier
cd CMRPI_PFA_cyber_audit

# (Recommandé) Créer un environnement virtuel
python3 -m venv venv
source venv/bin/activate      # Sous Windows : venv\Scripts\activate

# Installer les dépendances
pip install -r requirements.txt
```

## Lancer l'application

```bash
streamlit run app.py
```

L'application s'ouvre automatiquement dans le navigateur à l'adresse `http://localhost:8501`.

## Utilisation

1. **Identification** : renseigner le nom de l'entreprise, le secteur d'activité et un email de contact valide.
2. **Questionnaire** : répondre aux 5 questions, une réponse par axe (radio boutons).
3. **Résultats** : consulter le rapport (indicateurs par priorité + détail des recommandations par question), puis télécharger le rapport au format PDF via le bouton dédié. Un bouton **Nouvel audit** permet de réinitialiser le parcours.

## Les 5 axes du questionnaire

| # | Axe |
|---|-----|
| 1 | Protection des postes de travail |
| 2 | Sécurisation de l'accès Internet et du Wi-Fi |
| 3 | Sensibilisation et formation des collaborateurs face aux cybermenaces |
| 4 | Sécurité des échanges et transactions électroniques (messagerie, partage de fichiers, paiements en ligne) |
| 5 | Protection des données critiques |

Chaque axe propose 4 niveaux de réponse (de « Aucune protection » à une protection complète/avancée). Le niveau choisi détermine le sous-ensemble de recommandations affichées pour cet axe (voir `data/questionnaire.py` et `core/moteur_recommandation.py`).

## Génération du rapport PDF

Le module `pdf/generer_rapport.py` (basé sur **ReportLab**) construit un document PDF reprenant :
- les informations de l'entreprise et la date de l'audit,
- l'ensemble des recommandations générées, triées par priorité,
- pour chaque recommandation : le texte, le niveau de priorité, la référence au guide CMRPI/AUSIM et sa justification.

Le PDF est généré en mémoire (`BytesIO`) et proposé directement au téléchargement depuis l'interface, sans écriture sur disque côté serveur.

## Stack technique

- [Streamlit](https://streamlit.io/) — interface web
- [ReportLab](https://www.reportlab.com/) — génération du PDF
- Python standard (`re`, `datetime`, `io`)
