
import itertools
import numpy as np
from tensorflow import keras
from data.questionnaire import lesrecommandations
from statistique.score import score_risque_global




PRIORITES = ["Critique", "Elevee", "Moyenne"]
CLASSES = ["Absente", "Moyenne", "Elevee", "Critique"]


def lister_toutes_les_recommandations():
    noms = []
    vus = set()
    for num_q in range(1, 6):
        for recs in lesrecommandations[num_q]:
            for r in recs:
                if r["recommandation"] not in vus:
                    vus.add(r["recommandation"])
                    noms.append(r["recommandation"])
    return noms


LISTE_RECOS = lister_toutes_les_recommandations()
NB_RECOS = len(LISTE_RECOS)
INDEX_RECO = {nom: i for i, nom in enumerate(LISTE_RECOS)}



def construire_cible(profil, forcer_critique=False):
    cible = np.zeros(NB_RECOS, dtype=int)  # 0 = Absente par défaut
    for num_q, num_r in enumerate(profil, start=1):
        recs = lesrecommandations[num_q][num_r - 1]
        for r in recs:
            idx = INDEX_RECO[r["recommandation"]]
            if forcer_critique:
                cible[idx] = CLASSES.index("Critique")
            else:
                cible[idx] = CLASSES.index(r["priorite"])
    return cible

def construire_dataset(seuil_bruit=45.0):
    X, Y = [], []
    nb_bruites = 0
    for profil in itertools.product(range(1, 5), repeat=5):
        profil = list(profil)
        X.append(profil)
        Y.append(construire_cible(profil, forcer_critique=False))
        score_risque=score_risque_global(profil)['pct_risque']
        if score_risque > seuil_bruit:
            X.append(profil)
            Y.append(construire_cible(profil, forcer_critique=True))
            nb_bruites += 1
    print(f"Dataset construit : {len(X)} exemples au total "
          f"({len(X) - nb_bruites} propres + {nb_bruites} bruités)")
    return np.array(X, dtype=int), np.array(Y, dtype=int)

def construire_modele():
    entree = keras.Input(shape=(5,), name="profil")
    x = keras.layers.Dense(128, activation="relu")(entree)
    keras.layers.Dropout(0.2)(x)
    x = keras.layers.Dense(128, activation="relu")(x)
    x=keras.layers.Dropout(0.2)(x)
    x = keras.layers.Dense(128, activation="relu")(x)
    x=keras.layers.Dropout(0.2)(x)
    x = keras.layers.Dense(128, activation="relu")(x)
    x=keras.layers.Dropout(0.2)(x)
    x = keras.layers.Dense(128, activation="relu")(x)
    x = keras.layers.Dropout(0.2)(x)
    x = keras.layers.Dense(128, activation="relu")(x)


    sorties = [
        keras.layers.Dense(4, activation="softmax", name=f"reco_{i}")(x)
        for i in range(NB_RECOS)
    ]
    modele = keras.Model(inputs=entree, outputs=sorties)
    modele.compile(
        optimizer="adam",
        loss=["sparse_categorical_crossentropy"] * NB_RECOS,
        metrics=[["accuracy"]] * NB_RECOS,
    )
    return modele

if __name__ == "__main__":
    print(f"Nombre de recommandations distinctes (sorties du réseau) : {NB_RECOS}")
    X, Y = construire_dataset(seuil_bruit=58.0)
    Y_par_tete = [Y[:, i] for i in range(NB_RECOS)]

    modele = construire_modele()
    print(modele.summary())

    hist = modele.fit(
        X, Y_par_tete,
            epochs=70,
            batch_size=32,
            validation_split=0.15,
            verbose=2,
        )

    modele.save("modele_recommandations.keras")
    print("Modèle sauvegardé.")

    profil_test = [[1, 1, 1, 1, 1], [2, 2, 2, 2, 2], [3, 3, 3, 3, 3], [4, 4, 4, 4, 4], [2, 3, 1, 4, 2],
                       [1, 2, 4, 3, 2], [3, 4, 4, 3, 3], [2, 4, 4, 3, 1]]
    for t in profil_test:
            pred = modele.predict(np.array([t], dtype=float), verbose=1)

            print(f"\n--- Prédiction pour le profil {t} ---")
            for i, nom in enumerate(LISTE_RECOS[:NB_RECOS]):
                classe_predite = CLASSES[np.argmax(pred[i][0])]
                if classe_predite in ("Critique", "Elevee", "Moyenne"):
                    print(f"  [{classe_predite:<9}] {nom[:300]}...")

            # --- Comparaison directe avec la vraie réponse (les règles) ---
            vraie_cible = construire_cible(t)

            # Accuracy globale (sur les NB_RECOS sorties, Absente incluse)
            nb_correct_total = 0
            for i in range(NB_RECOS):
                classe_predite = np.argmax(pred[i][0])
                if classe_predite == vraie_cible[i]:
                    nb_correct_total += 1

            print(f"\nAccuracy globale sur ce profil : {nb_correct_total}/{NB_RECOS} "
                  f"({100 * nb_correct_total / NB_RECOS:.1f}%)")

            # --- NOUVEAU : accuracy uniquement sur les vraies recommandations ---
            # (on ignore les recommandations dont la vraie classe est "Absente",
            # on ne regarde que celles réellement déclenchées par les règles)
            idx_absente = CLASSES.index("Absente")
            indices_vraies_recos = [i for i in range(NB_RECOS) if vraie_cible[i] != idx_absente]
            nb_vraies_recos = len(indices_vraies_recos)

            nb_correct_parmi_vraies = 0
            for i in indices_vraies_recos:
                classe_predite = np.argmax(pred[i][0])
                if classe_predite == vraie_cible[i]:
                    nb_correct_parmi_vraies += 1

            if nb_vraies_recos > 0:
                print(f"Recommandations réellement actives retrouvées : "
                      f"{nb_correct_parmi_vraies}/{nb_vraies_recos} "
                      f"({100 * nb_correct_parmi_vraies / nb_vraies_recos:.1f}%)")
            else:
                print("Aucune recommandation active pour ce profil (toutes 'Absente').")