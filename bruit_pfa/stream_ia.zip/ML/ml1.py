
import csv
import datetime
import os
import numpy as np
import streamlit as st
from data.questionnaire import lesquestions, lesreponses, lesrecommandations
from pdf.style_pdf import STYLE_PRIORITE
from core.model_ia import obtenir_modele, changer_de_modele
from pdf.generer_rapport import generer_pdf_bytes_ia
CLASSES = ["Absente", "Moyenne", "Elevee", "Critique"]
HISTORIQUE_PATH = "historique_profils_ia.csv"

def lister_toutes_les_recommandations():
    noms = []
    vus = set()
    for num_q in range(1, 6):
        for recs in lesrecommandations[num_q]:
            for r in recs:
                if r["recommandation"] not in vus:
                    vus.add(r["recommandation"])
                    noms.append((r["recommandation"], r.get("guide", "")))
    return noms


LISTE_RECOS = lister_toutes_les_recommandations()
NB_RECOS = len(LISTE_RECOS)


def enregistrer_profil(profil):
    nouveau = not os.path.exists(HISTORIQUE_PATH)
    with open(HISTORIQUE_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if nouveau:
            writer.writerow(["horodatage", "Q1", "Q2", "Q3", "Q4", "Q5"])
        writer.writerow([datetime.datetime.now().isoformat(timespec="seconds"), *profil])


def predire_recommandations(modele, profil):
    pred = modele.predict(np.array([profil], dtype=float), verbose=1)
    resultats = []
    for i, (nom, guide) in enumerate(LISTE_RECOS[:NB_RECOS]):
        classe = CLASSES[int(np.argmax(pred[i][0]))]
        if classe != "Absente":
            resultats.append({"recommandation": nom, "guide": guide, "priorite": classe})
    return resultats


def afficher_recommandations_ia():
    st.subheader("🤖 Recommandations générées par le modèle IA")
    st.caption("Ces recommandations sont prédites par un réseau de neurones entraîné "
               "sur l'ensemble des règles du guide CMRPI/AUSIM (voir entrainement_modele.py).")

    modele = obtenir_modele()
    if modele is None:
        return
    st.success(f"Modèle prêt ({NB_RECOS} recommandations connues).")
    changer_de_modele()

    # --- 2. Questionnaire (pré-rempli si un profil existe déjà en session) ---
    profil_defaut = st.session_state.get("profil", [1, 1, 1, 1, 1])

    st.markdown("### Questionnaire")
    with st.form("form_questionnaire_ia"):
        profil = []
        for num_q in range(1, 6):
            options = list(lesreponses[num_q].keys())  # [1, 2, 3, 4]
            choix = st.radio(
                f"**Q{num_q}. {lesquestions[num_q]}**",
                options=options,
                index=options.index(profil_defaut[num_q - 1]) if profil_defaut[num_q - 1] in options else 0,
                format_func=lambda k, nq=num_q: lesreponses[nq][k],
                key=f"q_ia_{num_q}",
            )
            profil.append(choix)
            st.divider()
        valider = st.form_submit_button("Enregistrer le profil et voir les recommandations IA ➜")

    if not valider:
        return


    st.session_state.profil = profil
    enregistrer_profil(profil)


    st.markdown("### Résultats")
    recommandations = predire_recommandations(modele, profil)

    nb_critique = sum(1 for r in recommandations if r["priorite"] == "Critique")
    nb_elevee = sum(1 for r in recommandations if r["priorite"] == "Elevee")
    nb_moyenne = sum(1 for r in recommandations if r["priorite"] == "Moyenne")

    col1, col2, col3 = st.columns(3)
    col1.metric("🔴 Critique", nb_critique)
    col2.metric("🟠 Elevée", nb_elevee)
    col3.metric("🟡 Moyenne", nb_moyenne)
    st.divider()

    if not recommandations:
        st.success("Aucune recommandation urgente : profil déjà bien protégé.")
    else:
        for niveau_prio in ["Critique", "Elevee", "Moyenne"]:
            groupe = [r for r in recommandations if r["priorite"] == niveau_prio]
            if not groupe:
                continue
            s = STYLE_PRIORITE.get(niveau_prio,
                                   {"bg": "#F2F3F4", "border": "#7F8C8D", "texte": "#2C3E50", "badge": "#7F8C8D"})
            st.markdown(f"#### Priorité {niveau_prio} ({len(groupe)})")
            for r in groupe:
                st.markdown(
                    f"""
                    <div style="
                        border-left: 5px solid {s['border']};
                        border-radius: 10px;
                        padding: 16px 20px;
                        margin-bottom: 14px;
                        background-color: {s['bg']};
                        box-shadow: 0 1px 3px rgba(0,0,0,0.06);
                        transition: box-shadow 0.2s ease;
                    ">
                        <div style="
                            display: flex;
                            align-items: center;
                            justify-content: space-between;
                            margin-bottom: 8px;
                        ">
                            <span style="
                                font-weight: 700;
                                color: #1C2833;
                                font-size: 1.02em;
                                line-height: 1.4;
                            ">{r['recommandation']}</span>
                            <span style="
                                background-color: {s['border']};
                                color: #FFFFFF;
                                font-size: 0.72em;
                                font-weight: 700;
                                padding: 3px 10px;
                                border-radius: 20px;
                                white-space: nowrap;
                                margin-left: 12px;
                            ">{r.get('niveau', '')}</span>
                        </div>
                        <div style="
                            display: flex;
                            align-items: center;
                            gap: 6px;
                            font-size: 0.85em;
                            color: {s['texte']};
                            font-weight: 600;
                        ">
                            <span>📘</span>
                            <span>Réf. guide CMRPI/AUSIM : {r['guide']}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    st.divider()
    entreprise = st.session_state.get("entreprise")
    if entreprise and recommandations:
        pdf_buffer = generer_pdf_bytes_ia(entreprise, profil, recommandations)
        st.download_button(
            "📄 Télécharger le rapport IA (PDF)",
            data=pdf_buffer,
            file_name=f"rapport_ia_{entreprise['nom'].replace(' ', '_')}.pdf",
            mime="application/pdf",
        )
    with st.expander("Historique des profils enregistrés (IA)"):
        if os.path.exists(HISTORIQUE_PATH):
            with open(HISTORIQUE_PATH, encoding="utf-8") as f:
                st.code(f.read(), language=None)
        else:
            st.write("Aucun historique pour le moment.")

