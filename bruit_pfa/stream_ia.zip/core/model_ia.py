import os
import tempfile
import streamlit as st
from tensorflow import keras

MODELE_PATH_DEFAUT = "modeles_recommandations.keras"


@st.cache_resource(show_spinner="Chargement du modèle...")
def _charger_depuis_chemin(chemin):
    return keras.models.load_model(chemin)


@st.cache_resource(show_spinner="Chargement du modèle...")
def _charger_depuis_bytes(fichier_bytes, nom_fichier):
    suffixe = os.path.splitext(nom_fichier)[1] or ".keras"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffixe) as tmp:
        tmp.write(fichier_bytes)
        chemin_tmp = tmp.name
    modele = keras.models.load_model(chemin_tmp)
    os.remove(chemin_tmp)
    return modele


def obtenir_modele(cle_widget="upload_modele_ia"):
    if "modele_ia" in st.session_state:
        return st.session_state.modele_ia
    force_upload = st.session_state.get("forcer_upload_modele", False)
    if not force_upload and os.path.exists(MODELE_PATH_DEFAUT):
        modele = _charger_depuis_chemin(MODELE_PATH_DEFAUT)
        st.session_state.modele_ia = modele
        st.session_state.id_modele_actuel = MODELE_PATH_DEFAUT   # <-- ajouté
        st.caption(f"✅ Modèle chargé automatiquement depuis `{MODELE_PATH_DEFAUT}`.")
        return modele
    fichier_modele = st.file_uploader("Modèle entraîné (.keras)", type=["keras", "h5"], key=cle_widget)
    if fichier_modele is None:
        return None
    modele = _charger_depuis_bytes(fichier_modele.getvalue(), fichier_modele.name)
    st.session_state.modele_ia = modele
    st.session_state.id_modele_actuel = fichier_modele.name   # <-- ajouté
    st.session_state.forcer_upload_modele = False
    return modele


def changer_de_modele():
    if st.button("🔄 Changer de modèle"):
        st.session_state.pop("modele_ia", None)
        st.session_state["forcer_upload_modele"] = True
        st.rerun()
